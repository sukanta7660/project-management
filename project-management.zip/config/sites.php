<?php
return [
    'site_info' => [],
    'task_statuses' => [
        'pending','not-required','in-progress','next-day','continue','done'
    ]
];
